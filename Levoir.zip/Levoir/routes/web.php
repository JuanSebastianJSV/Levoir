<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('my-layouts.home-guest');
});

Route::get('/home','HomeController@index')->name('home');
Route::get('/home-user','HomeUserController@index')->name('home-user')->middleware('auth');

Route::get('/register','RegisterController@showRegisterForm')->name('register');
Route::post('/register','RegisterController@register')->name('register');

Route::get('/login','LoginController@showLoginForm')->name('login');
Route::post('/login','LoginController@login')->name('login');

Route::get('/logout','LoginController@logout')->name('logout')->middleware('auth');

Route::get('/attire-detail/{id}','AttireDetail@index')->name('attire-detail')->middleware('auth');

Route::get('/add-to-cart/{id}','AddToCart@index')->name('add-to-cart')->middleware('auth');
Route::post('/add-to-cart/{id}','AddToCart@order')->name('add-to-cart')->middleware('auth');
Route::get('/view-cart','AddToCart@cart')->name('view-cart')->middleware('auth');

Route::get('/view-cart','AddToCart@cart')->name('view-cart')->middleware('auth');
Route::get('/checkout','AddToCart@checkout')->name('checkout')->middleware('auth');

Route::get('/view-transaction','Transaction@index')->name('view-transaction')->middleware('auth');
Route::get('transaction-detail/{id}','Transaction@detail')->name('transaction-detail')->middleware('auth');

Route::get('/add-attire','AddAttire@index')->name('add-attire')->middleware('auth');
Route::post('add-attire','AddAttire@add')->name('add-attire')->middleware('auth');

Route::get('/view-your-attire','ViewYourAttire@index')->name('view-your-attire')->middleware('auth');

Route::get('/view-your-attire-detail/{id}','ViewYourAttireDetail@index')->name('view-your-attire-detail')->middleware('auth');

Route::get('view-your-attire-detail-detail/{id}','ViewYourAttireDetailDetail@index')->name('view-your-attire-detail-detail')->middleware('auth');

Route::get('/edit-cart/{id}','EditCart@index')->name('edit-cart')->middleware('auth');
Route::post('/edit-cart/{id}','EditCart@update')->name('edit-cart')->middleware('auth');
Route::delete('/delete-cart/{id}','EditCart@delete')->name('delete-cart')->middleware('auth');
Route::get('/view-admin-all-attire','ViewAdminAllAttire@index')->name('view-admin-all-attire')->middleware('auth');

Route::get('/add-attire-admin','AddAttireAdmin@index')->name('add-attire-admin')->middleware('auth');
Route::post('add-attire-admin','AddAttireAdmin@add')->name('add-attire-admin')->middleware('auth');

Route::get('/update-attire/{id}','UpdateAttire@index')->name('update-attire')->middleware('auth');
Route::patch('update-attire/{id}','UpdateAttire@update')->name('update-attire')->middleware('auth');

Route::get('/view-all-transaction','ViewAllTransaction@index')->name('view-all-transaction');

Route::get('view-all-transaction-detail/{id}','AllTransactionDetails@detail')->name('view-all-transaction-detail')->middleware('auth');