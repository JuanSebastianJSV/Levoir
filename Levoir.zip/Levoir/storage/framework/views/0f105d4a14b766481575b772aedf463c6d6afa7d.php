<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add attire to Cart</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class="edit-cart">

<!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul Edit Cart pada Route ini -->
<?php $__env->startSection('title','Edit Cart'); ?>

<?php $__env->startSection('content'); ?>

<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
    
<div class="row">

      <ul class="navbar-nav martop20 marleft text-white">

        <li class="nav-item active text-white">
        <a class="nav-link text-white" href="<?php echo e(Route('home-user')); ?>">View Attire <span class="sr-only">(current)</span> </a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white " href="<?php echo e(Route('view-cart')); ?>">View Cart</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('view-transaction')); ?>">View Transaction</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('add-attire')); ?>">Add Attire</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('view-your-attire')); ?>">View Your Attire</a>
        </li>

      </ul>
    </div>
</div>
</nav>

<!-- Menampilkan sebuah card view berupa form yang bisa melakukan update quantity atau delete item pada cart -->
<div class="card-header d-flex justify-content-center text-white">Edit Cart</div>
<div class = "card marleft" style="width: 18rem;">
<div>
<form method="post" action="<?php echo e(url('edit-cart')); ?>/<?php echo e($order_detail->attire->id); ?>">
<?php echo csrf_field(); ?>
<img src="<?php echo e(url('assets')); ?>/<?php echo e($order_detail->attire->image); ?>" style="width:288px;height:200px;">
 <div class="container">
<h4>Name: <?php echo e($order_detail->attire->name); ?></h4>
<br>
Price: <?php echo e($order_detail->attire->price); ?>

<br>
Description: <?php echo e($order_detail->attire->description); ?>

<br>
<br>
Quantity
<input class="form-control mr-sm-2" type="text" placeholder="" aria-label="Quantity" name="quantity">
<br>
<br>
Renting Time (Days)
<input class="form-control mr-sm-2" type="text" placeholder="" aria-label="Rent Time" name="rent_time">
<br>
<br>
<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Update Cart!</button>
</form>
<br>
<br>
<form method="post" action="<?php echo e(url('delete-cart')); ?>/<?php echo e($order_detail->id); ?>">
<?php echo csrf_field(); ?>
<?php echo e(method_field('DELETE')); ?>

<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Delete</button>
</form>
</div>
</div>


<?php $__env->stopSection(); ?>

<!-- Kode javascript untuk bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/edit-cart.blade.php ENDPATH**/ ?>