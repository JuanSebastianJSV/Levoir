<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Shoe to Cart</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class = "add-to-cart">
<!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul Add Shoe to Cart pada Route ini -->
<?php $__env->startSection('title','Add to Cart'); ?>

<?php $__env->startSection('content'); ?>

<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
    <?php if(auth()->guard()->check()): ?>
<div class="row">

      <ul class="navbar-nav martop20 marleft">

        <li class="nav-item active text-white">
        <a class="nav-link text-white " href="<?php echo e(Route('home-user')); ?>">View Attire</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white " href="<?php echo e(Route('view-cart')); ?>">View Cart</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('view-transaction')); ?>">View Transaction</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('add-attire')); ?>">Add Attire</a>
        </li>

        <li class="nav-item text-white marleft">
        <a class="nav-link text-white" href="<?php echo e(Route('view-your-attire')); ?>">View Your Attire</a>
        </li>

      </ul>
    </div>
</div>
</nav>

<!-- Header Add to Cart -->
 <div class="card-header d-flex justify-content-center text-white">Add to Cart</div>

<!-- Menampilkan sebuah form berupa card view untuk Add Shoe ke dalam card, yang terdiri atas Gambar sepatu, nama sepatu, harga sepatu, Description sepatu, Quantity dari sepatu yang bisa diinput sendiri oleh user-->
<div class = "card marleft" style="width: 18rem;">
<div>

<!-- Membuat sebuah form dengan methode post untuk memasukkan quantity shoe yang diinginkan user berdasarkan image, price, description dan quantity yang ada -->
<form method="post" action="<?php echo e(url('add-to-cart')); ?>/<?php echo e($attire->id); ?>">
<?php echo csrf_field(); ?>
<img src="<?php echo e(url('assets')); ?>/<?php echo e($attire->image); ?>" style="width:288px;height:200px;">
 <div class="container">
<h4>Name: <?php echo e($attire->name); ?></h4>
<br>
<br>
Price: <?php echo e($attire->price); ?>

<br>
<br>
Owner: <?php echo e($attire -> seller); ?>

<br>
<br>
Stock: <?php echo e($attire -> stock); ?>

<br>
<br>
Description: <?php echo e($attire->description); ?>

<br>
<br>
Quantity
<input class="form-control mr-sm-2" type="text" placeholder="" aria-label="Quantity" name="quantity">
<br>
<br>
Renting Time (Days)
<input class="form-control mr-sm-2" type="text" placeholder="" aria-label="Rent Time" name="rent_time">
<br>
<br>
<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Add to Cart!</button>
</form>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<!-- Kode javascript untuk bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/add-to-cart.blade.php ENDPATH**/ ?>