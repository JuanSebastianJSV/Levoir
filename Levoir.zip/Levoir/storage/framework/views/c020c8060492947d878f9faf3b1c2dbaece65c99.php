<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transaction Detail</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class="view-all-transaction-detail">
  <!-- Mengambil navigation bar dari mylayouts.master -->



<!-- Memberikan judul View All Transaction Detail pada Route ini -->
<?php $__env->startSection('title','View All Transaction Detail'); ?>

<?php $__env->startSection('content'); ?>
<!-- Navigation Bar untuk View All Shoe, Add Shoe, Update Shoe dan View All Transaction (untuk admin) -->
<nav class="navbar navbar-expand-lg navbar-light">

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <?php if(auth()->guard()->check()): ?>

      <ul class="navbar-nav">

       <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('view-admin-all-attire')); ?>">View All Shoe</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('add-attire-admin')); ?>">Add Attire</span></a>
        </li>

        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(Route('view-all-transaction')); ?>">View All Transaction<span class="sr-only">(current)</span></a>
        </li>

      </ul>
    <?php endif; ?>

</div>
</nav>

<!-- Menampilkan seluruh detail transaksi yang ada di database berikut dengan gambar,nama, harga dan tanggal pembelian -->
<?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class = "card marleft" style="width: 18rem;">
<div>
<tr>
<td>
  <img src="<?php echo e(url('assets')); ?>/<?php echo e($od->attire->image); ?>"  alt="Card image cap" style="width:288px;height:200px;">
</td>
<td>Name: <?php echo e($od->attire->name); ?></td>
<br>
<td> Quantity: <?php echo e($od -> quantity); ?></td>
<br>
<td>Price: <?php echo e($od->attire->price); ?></td>
<br>
<td>Total Shoe Price: <?php echo e($od->total_price); ?></td>
<br>
<td> Transaction Date: <?php echo e($od->created_at); ?> </td>
<br>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/view-all-transaction-detail.blade.php ENDPATH**/ ?>