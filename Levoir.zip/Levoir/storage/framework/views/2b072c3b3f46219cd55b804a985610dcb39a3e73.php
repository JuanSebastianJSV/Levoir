<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View All Transaction</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class = "view-all-transaction">
  <!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul View All Transaction Detail pada Route ini -->

<?php $__env->startSection('title','View All Transaction'); ?>

<?php $__env->startSection('content'); ?>

<!-- Navigation Bar untuk View All Shoe, Add Shoe, Update Shoe dan View All Transaction (untuk admin) -->
<nav class="navbar navbar-expand-lg navbar-light">

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <?php if(auth()->guard()->check()): ?>

      <ul class="navbar-nav">

       <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('view-admin-all-attire')); ?>">View All Shoe</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('add-attire-admin')); ?>">Add Attire</span></a>
        </li>

        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(Route('view-all-transaction')); ?>">View All Transaction<span class="sr-only">(current)</span></a>
        </li>

      </ul>
    <?php endif; ?>

</div>
</nav>

<!-- Menampilkan seluruh  transaksi yang ada di database berikut dengan  tanggal pembelian, harga total dan nama pembeli -->
<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class = "card marleft" style="width: 18rem;">
<div>
<tr>
<td>
  <?php echo e($o->updated_at); ?>

</td>
<br>
<td>Total Shoe Price: <?php echo e($o->total_price); ?></td>
<br>
<td>User: <?php echo e($o->user->name); ?></td>
<br>
<br>
<a href="<?php echo e(url('view-all-transaction-detail')); ?>/<?php echo e($o->id); ?>"><button class="btn btn-outline-success my-2 my-sm-0 marleft" type="submit">Details</button></a>
<br>
</div>
</div>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/view-all-transaction.blade.php ENDPATH**/ ?>