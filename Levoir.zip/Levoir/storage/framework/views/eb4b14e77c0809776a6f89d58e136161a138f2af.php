<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home Admin</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class = "add-attire">
<!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul View All Shoe pada Route ini -->
<?php $__env->startSection('title','Home Admin'); ?>

<?php $__env->startSection('content'); ?>

<!-- Navigation Bar untuk View All Shoe, Add Shoe, Update Shoe dan View All Transaction (untuk admin) -->
<?php if(auth()->guard()->check()): ?>
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
<div class="row">

      <ul class="navbar-nav martop20 marleft">

        <li class="nav-item active text-black">
        <a class="nav-link text-black " href="<?php echo e(Route('view-admin-all-attire')); ?>">View Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black " href="<?php echo e(Route('add-attire-admin')); ?>">Add Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="<?php echo e(Route('view-all-transaction')); ?>">View All Transaction</a>
        </li>

      </ul>
    </div>
</div>
</nav>
<?php endif; ?>
<!-- Menampilan semua data shoe -->
<div class="d-flex flex-wrap martop20">

    <?php $__currentLoopData = $attire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
   <!-- Jika card ditekan, maka akan pergi ke view View Shoe Detail -->
   <div class="card marright marleft" style="width: 16rem;">

   <a href="<?php echo e(url('update-attire')); ?>/<?php echo e($a->id); ?>">
  <img class="card-img-top" src="<?php echo e(asset("../assets/$a->image")); ?>"  alt="Card image cap" style="width:254px;height:200px;">
    <div class="container">
    <h5 class="card-title"><?php echo e($a -> name); ?></h5>
    <p class="card-text">Owner: <?php echo e($a -> seller); ?></p>
    <p class="card-text">Stock: <?php echo e($a -> stock); ?></p>
    <p class = "card-text"> Rp. <?php echo e($a -> price); ?> </p>
    </div>
    </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <!-- Jika sepatu yang tampil lebih dari 6, maka akan dipindahkan ke halaman lain dengan menggunakan paginate, dan paginate bisa berjalan jika ada fungsi ini-->
    <?php echo e($attire->withQueryString()->links()); ?>

<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/view-admin-all-attire.blade.php ENDPATH**/ ?>