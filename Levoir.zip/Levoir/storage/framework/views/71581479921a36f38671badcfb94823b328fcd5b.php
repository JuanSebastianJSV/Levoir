<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class="register">
<!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul Register pada Route ini -->
<?php $__env->startSection('title','register'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->startSection('content'); ?>

<!-- Form card view untuk register yang berisi username, email address, password dan confirm password -->
<div class="d-flex justify-content-center">
    <div class="card border-primary mb-3" style="width: 500px">
        <div class="card-header d-flex justify-content-center bg-primary mb-3">Register as Customer</div>
        <div class="card-body text-primary">
            <form action="<?php echo e(Route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <pre> Username              <input type="text" placeholder="Name" name="name"></pre>

                <pre> E-Mail Address        <input type="text" placeholder="Email" name="email"></pre>

                <pre> Password              <input type="password" placeholder="Password" name="password"></pre>

                <pre> Confirm Password      <input type="password" placeholder="Confirm Password" name="c_password"></pre>

                <div class="d-flex justify-content-center">
                <input type="submit" value="Register" class="btn btn-primary">
                </div>
                <br>
        
            </form>
        </div>
        
    </div>
</div>


    
    <!-- Jika terjadi error, maka akan menampilkan error page -->
	<?php if($errors -> any()): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($error); ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	<br>

<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/register.blade.php ENDPATH**/ ?>