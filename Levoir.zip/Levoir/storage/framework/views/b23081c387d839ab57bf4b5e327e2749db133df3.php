<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Attire</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class = "add-attire-admin">

<!-- Mengambil navigation bar dari mylayouts.master -->


<!-- Memberikan judul Add Shoe pada Route ini -->
<?php $__env->startSection('title','Add Attire'); ?>

<?php $__env->startSection('content'); ?>

<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<nav class="navbar navbar-expand-lg navbar-light">

    <div class="collapse navbar-collapse" id="navbarNavDropdown">

      <!-- Jika user terauth, maka View All Shoe, View Cart dan View Transaction akan tampil pada View, tetapi jika tidak hanya View All Shoe yang tampil -->
    <?php if(auth()->guard()->check()): ?>

      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('view-admin-all-attire')); ?>">View Attire</a>
        </li>

        
          <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(Route('add-attire')); ?>">Add Attire<span class="sr-only">(current)</span></a>
        </li>


        <li class="nav-item">
          <a class="nav-link" href="">View All Transaction</a>
        </li>

      </ul>
    <?php endif; ?>

</div>
</nav>

<!-- Menampilkan sebuah form untuk Admin berupa card view untuk Add Shoe ke dalam database, yang terdiri atas Gambar sepatu, nama sepatu, harga sepatu dan Description sepatu dari sepatu yang bisa diinput sendiri oleh admin-->
<div class="card marright marleft" style="width: 18rem;">
	<div class="container">
	<form action="<?php echo e(Route('add-attire-admin')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<br>
Add Attire
<br>
<br>
Attire Name
<input class="form-control mr-sm-2" type="text" placeholder="" name="attire_name">
<br>
<br>
Attire Price
<br>
<input class="form-control mr-sm-2" type="text" placeholder="" name="attire_price">
<br>
<br>
Attire Description
<input  class="form-control mr-sm-2" type="text" placeholder="" name="attire_description"> 
<br>
<br>
Attire Stock
<input  class="form-control mr-sm-2" type="text" placeholder="" name="attire_stock"> 
<br>
<br>
<input type="file" placeholder="Choose File" name="attire_image">
<br>
<br>
<input class="btn btn-outline-success my-2 my-sm-0"type="submit" value="Add Attire">
</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Kode javascript untuk bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php echo $__env->make('my-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/add-attire-admin.blade.php ENDPATH**/ ?>