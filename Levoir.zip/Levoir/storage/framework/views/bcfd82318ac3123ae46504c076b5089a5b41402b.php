<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<div class="topnav">
        <!-- Logo -->
        <H1>LEVOIR</H1>
        <!-- Jika user terauth, maka menu nama user, search, logout dan admin akan muncul -->
        <?php if(auth()->guard()->check()): ?>
        <a id="navbar" class="nav-link" href="<?php echo e(Route('view-admin-all-attire')); ?>" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                Admin
            </a>
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php echo e(Auth::user()->name); ?>

            </a>
            <form class="form-inline my-2 my-lg-0">
                <?php echo csrf_field(); ?>
                <input class="form-control mr-sm-2 martop20" type="text" placeholder="Search" name="search">
                <button class="btn btn-outline-success martop20" type="submit">Search</button>
              </form>

            <div class="dropdown-menu dropdown-menu-right bg-dark" aria-labelledby="navbarDropdown">
                <div class="logout bg-dark">
                <a class="dropdown-item text-black" href="<?php echo e(route('logout')); ?>">Logout
            </div>
                </a>

            </div>
            
			<ul class="navbar-nav ml-auto">
                <!-- Jika user tidak terauth, menu login dan register akan muncul-->

                        <?php if(auth()->guard()->guest()): ?>

                        <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>

		<?php else: ?>
			<a href="<?php echo e(Route('login')); ?>">Login</a>
			<a href="<?php echo e(Route('register')); ?>">Register</a>
            <?php endif; ?>
    </div>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\Projects\Web Projects\Levoir\resources\views/my-layouts/master.blade.php ENDPATH**/ ?>