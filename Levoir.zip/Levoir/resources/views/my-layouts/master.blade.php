<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
</head>
<body>
<div class="topnav">
        <!-- Logo -->
        <H1>LEVOIR</H1>
        <!-- Jika user terauth, maka menu nama user, search, logout dan admin akan muncul -->
        @auth
        <a id="navbar" class="nav-link" href="{{Route('view-admin-all-attire')}}" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                Admin
            </a>
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                {{ Auth::user()->name }}
            </a>
            <form class="form-inline my-2 my-lg-0">
                @csrf
                <input class="form-control mr-sm-2 martop20" type="text" placeholder="Search" name="search">
                <button class="btn btn-outline-success martop20" type="submit">Search</button>
              </form>

            <div class="dropdown-menu dropdown-menu-right bg-dark" aria-labelledby="navbarDropdown">
                <div class="logout bg-dark">
                <a class="dropdown-item text-black" href="{{ route('logout') }}">Logout
            </div>
                </a>

            </div>
            
			<ul class="navbar-nav ml-auto">
                <!-- Jika user tidak terauth, menu login dan register akan muncul-->

                        @guest

                        <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @endguest
                    </ul>

		@else
			<a href="{{Route('login')}}">Login</a>
			<a href="{{Route('register')}}">Register</a>
            @endauth
    </div>
	@yield('content')
</body>
</html>