<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Attire</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class="update-attire">
<!-- Mengambil navigation bar dari mylayouts.master -->
@extends('my-layouts.master')

<!-- Memberikan judul Update Shoe pada Route ini -->
@section('title','Update Attire')

@section('content')

<!-- Navigation Bar untuk View All Shoe, Add Shoe dan View All Transaction (untuk admin) -->
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
<div class="row">

      <ul class="navbar-nav martop20 marleft">

        <li class="nav-item active text-black">
        <a class="nav-link text-black " href="{{Route('home-user')}}">View Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black " href="{{Route('add-attire-admin')}}">Add Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('view-transaction')}}">View All Transaction</a>
        </li>

      </ul>
    </div>
</div>
</nav>


<!-- Menampilkan sebuah form berupa card view yang berisi Nama sepatu, harga sepatu, deskripsi sepatu dari database dan kemudian melakukan update ketika disubmit -->
<div class="card marright marleft" style="width: 18rem;">
	<div class="container">
	<form action="{{url('update-attire')}}/{{$attire->id}}" method="post" enctype="multipart/form-data">
@csrf
@method('patch')
<br>
Update Attire
<br>
<br>
Attire Name
<input class="form-control mr-sm-2" type="text" placeholder="" name="attire_name">
<br>
<br>
Price
<br>
<input class="form-control mr-sm-2" type="text" placeholder="" name="attire_price">
<br>
<br>
Description
<input  class="form-control mr-sm-2" type="text" placeholder="" name="attire_description"> 
<br>
<br>
Stock
<input  class="form-control mr-sm-2" type="text" placeholder="" name="attire_stock"> 
<br>
<br>
<input type="file" placeholder="Choose File" name="attire_image">
<br>
<br>
<input class="btn btn-outline-success my-2 my-sm-0"type="submit" value="Update Attire">
</form>
</div>
</div>
@endsection

<!-- Kode javascript untuk bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>