<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Lent Attire Detail</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class="transaction-detail">
<!-- Mengambil navigation bar dari mylayouts.master -->

@extends('my-layouts.master')

<!-- Memberikan judul Transaction Detail pada Route ini -->
@section('title','View Lent Attire Detail')

@section('content')
<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
<div class="row">

      <ul class="navbar-nav martop20 marleft">

        <li class="nav-item active text-black">
        <a class="nav-link text-black " href="{{Route('home-user')}}">View Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black " href="{{Route('view-cart')}}">View Cart</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('view-transaction')}}">View Transaction</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('add-attire')}}">Add Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('view-your-attire')}}">View Your Attire</a>
        </li>

      </ul>
    </div>
</div>
</nav>

<!-- Menampilkan seluruh detail transaksi yang ada di database berikut dengan gambar,nama, harga dan tanggal pembelian -->
<h2 class="text-white marleft"> View Each Lent Attire Detail </h2>
@foreach($order_detail as $od)
<div class = "card marleft" style="width: 18rem;">
<div>
<tr>
<td>
  <img src="{{url('assets')}}/{{$od->attire->image}}"  alt="Card image cap" style="width:288px;height:200px;">
</td>
<td>Name: {{$od->attire->name}}</td>
<br>
<td> Quantity: {{$od -> quantity}}</td>
<br>
<td>Price: {{$od->attire->price}}</td>
<br>
<td>Total Price: {{$od->total_price}}</td>
<br>
<td>Lent to: {{$od->order->user->name}}</td>
<br>
<td>Rental Time: {{$od->rent_time}} days</td>
<br>
<td> Transaction Date: {{$od->created_at}} </td>
<br>
<td> Return Date: {{date('Y-m-d H:i:s', strtotime($od->created_at. " + $od->rent_time days"))}} </td>
<br>
</div>
</div>
@endforeach
@endsection

<!-- Kode javascript untuk bootstrap -->

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>