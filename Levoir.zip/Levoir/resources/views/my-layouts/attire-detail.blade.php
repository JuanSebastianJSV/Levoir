<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Attire Detail</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body class = "attire-detail">

  <!-- Mengambil navigation bar dari mylayouts.master -->
@extends('my-layouts.master')

<!-- Memberikan judul View Shoe Detail pada Route ini -->
@section('title','View Attire Detail')

@section('content')

<!-- Navigation Bar untuk View All Shoe, View Cart dan View Transaction -->
<nav class="navbar navbar-expand-lg navbar-light martop200">

    <div class="collapse navbar-collapse martop200" id="navbarNavDropdown">
    @auth
<div class="row">

      <ul class="navbar-nav martop20 marleft text-black">

        <li class="nav-item active text-black">
        <a class="nav-link text-black" href="{{Route('home-user')}}">View Attire <span class="sr-only">(current)</span> </a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black " href="{{Route('view-cart')}}">View Cart</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('view-transaction')}}">View Transaction</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('add-attire')}}">Add Attire</a>
        </li>

        <li class="nav-item text-black marleft">
        <a class="nav-link text-black" href="{{Route('view-your-attire')}}">View Your Attire</a>
        </li>

      </ul>
    </div>
</div>
</nav>


<div class = "card marleft" style="width: 18rem;">
<div>

<!-- Image Source -->
<img src="{{url('assets')}}/{{$attire->image}}" style="width:280px;height:200px;">
 <div class="container">
<!-- Nama Sepatu -->
<h4>Name: {{$attire->name}}</h4>
<br>
<!-- Harga Sepatu -->
Price: {{$attire->price}}
<br>
<!-- Deskripsi Sepatu -->
Description: {{$attire->description}}
<br>
<a href="{{url('add-to-cart')}}/{{$attire->id}}"><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Add to Cart</button></a>
@endauth
</div>
</div>

@endsection

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>