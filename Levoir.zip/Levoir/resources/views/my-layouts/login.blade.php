<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body class="login">

    <!-- Mengambil navigation bar dari mylayouts.master -->
    @extends('my-layouts.master')

<!-- Memberikan judul Login pada Route ini -->
@section('title','login')
<meta name="csrf-token" content="{{ csrf_token() }}">
@section('content')

<!-- Form card view untuk login yang berisi email address, password dan remember me -->
<div class="d-flex justify-content-center">
    <div class="card border-primary mb-3" style="width: 500px">
        <div class="card-header d-flex justify-content-center bg-primary mb-3">Login</div>
        <div class="card-body">
            <form action="{{Route('login')}}" method="post">
                @csrf

                <pre> E-Mail Address        <input type="text" placeholder="E-Mail Address" name="email"></pre>

                <pre> Password              <input type="password" placeholder="password" name="password"></pre>

                <pre>                       <input type="checkbox" name="rememberme"> Remember Me</pre>

                <div class="d-flex justify-content-center">
                <input type="submit" value="Login" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

<!-- Kode javascript untuk bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>