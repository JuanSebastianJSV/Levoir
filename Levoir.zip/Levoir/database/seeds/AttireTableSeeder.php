<?php

use Illuminate\Database\Seeder;

class AttireTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \Illuminate\Support\Facades\DB::table("attires")->insert([
            [
             "name" => "Nike Air Jordan 1 Low OG Chinese New Year",
             "price" => "7000000",
             "image" => "shoe1.jpg",
             "description" => "Nike Air Jordan 1 Low OG Chinese New Year",
             "seller" => "Qiqi Nana",
             "seller_email" => "qiqinana@gmail.com",
             "stock" => "3"
            ],
   
            [
                "name" => "Nike Air Jordan 1 Retro High Gold",
             "price" => "9900000",
             "image" => "shoe2.jpg",
             "description" => "Nike Air Jordan 1 Retro High Gold",
             "seller" => "Hu Tao",
             "seller_email" => "whotao@gmail.com",
             "stock" => "6"
            ],
   
            [
             "name" => "Nike Mercurial",
             "price" => "1200000",
             "image" => "shoe3.jpg",
             "description" => "Nike Mercurial",
             "seller" => "Chong Yun",
             "seller_email" => "chongyuncy@gmail.com",
             "stock" => "1"
            ],
   
            [
             "name" => "Nike Tiempo",
             "price" => "600000",
             "image" => "shoe4.jpg",
             "description" => "Nike Tiempo",
             "seller" => "Xing Qiu",
             "seller_email" => "xingqiu@gmail.com",
             "stock" => "12"
            ],
   
            [
             "name" => "Nike Air Vapormax",
             "price" => "1200000",
             "image" => "shoe5.jpg",
             "description" => "Nike Air Vapormax",
             "seller" => "Zhong Li",
             "seller_email" => "zhongli@gmail.com",
             "stock" => "4"
            ],
   
            [
             "name" => "Nike Magista",
             "price" => "800000",
             "image" => "shoe6.jpg",
             "description" => "Nike Magista",
             "seller" => "Ganyu Cocogoat",
             "seller_email" => "ganyu@gmail.com",
             "stock" => "9"
            ],
   
            [
             "name" => "Nike Chuteira",
             "price" => "900000",
             "image" => "shoe7.jpg",
             "description" => "Nike Chuteira",
             "seller" => "Tartaglia",
             "seller_email" => "tartaglia@gmail.com",
             "stock" => "6"
            ]
           ]);	
    }
}
