<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \Illuminate\Support\Facades\DB::table("users")->insert([
            [
             "name" => "Qiqi Nana",
             "email" => "qiqinana@gmail.com",
             "password" => Hash::make('qiqinana'),
             "role" => "Admin"
            ],

            [
                "name" => "Hu Tao",
                "email" => "whotao@gmail.com",
                "password" => Hash::make('whotao'),
                "role" => "Admin"
               ],

               [
                "name" => "Chong Yun",
                "email" => "chongyuncy@gmail.com",
                "password" => Hash::make('chongyun'),
                "role" => "Admin"
               ],

               [
                "name" => "Xing Qiu",
                "email" => "xingqiu@gmail.com",
                "password" => Hash::make('xqxqxq'),
                "role" => "Admin"
               ],

               [
                "name" => "Zhong Li",
                "email" => "zhongli@gmail.com",
                "password" => Hash::make('rexlapis'),
                "role" => "Admin"
               ],

               [
                "name" => "Ganyu Cocogoat",
                "email" => "ganyu@gmail.com",
                "password" => Hash::make('cocogoat'),
                "role" => "Admin"
               ],

               [
                "name" => "Tartaglia",
                "email" => "tartaglia@gmail.com",
                "password" => Hash::make('childe'),
                "role" => "Admin"
               ]
        ]);
    }
}
