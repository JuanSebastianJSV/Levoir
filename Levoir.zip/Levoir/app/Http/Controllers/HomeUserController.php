<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;

class HomeUserController extends Controller
{
    public function index(Request $request)
    {	
    	$search = $request -> get('search');
    	$attire = Attire::where("name",'like','%'.$search.'%')->paginate(6);
    	return view('my-layouts.home-user',compact('attire'));
    }
}