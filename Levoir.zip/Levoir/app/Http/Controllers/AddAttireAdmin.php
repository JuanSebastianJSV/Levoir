<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;
use Auth;

class AddAttireAdmin extends Controller
{
    function index(){
    	return view('my-layouts.add-attire-admin');
    }

    function validator(Request $request){
		return $request->validate([
			'attire_name' => 'required',
			'attire_price' => 'required',
			'attire_description' => 'required'
		]);
	}
    function add(Request $request){
        $attire_image = $request->file('assets');
       $attire_image = $request->attire_image;
        // if($shoe_image){
        //     $shoe_image->move('assets', $shoe_image->getClientOriginalName());
        // }
    	$this->validator($request);
    	$attire = new Attire();
    	$attire ->name = $request->attire_name;
    	$attire ->price = $request->attire_price;
    	$attire->description = $request->attire_description;
		$attire->stock = $request->attire_stock;
        $attire->seller = Auth::user()->name;
        $attire->seller_email = Auth::user()->email;
    	$attire->image = $request->attire_image->getClientOriginalName();
       $attire_image->move('assets',$attire_image->getClientOriginalName());
    	$attire->save();
    	return redirect('view-admin-all-attire');
    }
}
