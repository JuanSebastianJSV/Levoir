<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\OrderDetail;
use App\User;
use App\Attire;
use Illuminate\Support\Facades\Auth;
class ViewYourAttireDetail extends Controller
{
  public function index($id){
  	$order = Order::where('attire_id',$id)->where('status',1)->get();
  	return view('my-layouts.view-your-attire-detail',compact('order'));
  }

}
