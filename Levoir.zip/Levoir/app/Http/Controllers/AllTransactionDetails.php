<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\OrderDetail;

class AllTransactionDetails extends Controller
{
  public function detail($id){
  	$order = Order::where('id',$id)->first();
  	$order_detail = OrderDetail::where('order_id',$order->id)->get();

  	return view('my-layouts.view-all-transaction-detail',compact('order','order_detail'));
  }
}
