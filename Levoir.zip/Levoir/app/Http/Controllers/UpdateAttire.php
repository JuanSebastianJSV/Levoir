<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;

class UpdateAttire extends Controller
{
    function index($id){
    	$attire = Attire::find($id);
    	return view('my-layouts.update-attire',[
            'attire' => $attire
        ]);
    }

    function update(Request $request,$id){
        $attire_image = $request->file('assets');
       $attire_image = $request->attire_image;
    	$attire = Attire::find($id);
    	$attire ->name = $request->attire_name;
    	$attire ->price = $request->attire_price;
    	$attire->description = $request->attire_description;
		$attire->stock = $request->attire_stock;
    	$attire->image = $request->attire_image->getClientOriginalName();
       $attire_image->move('assets',$attire_image->getClientOriginalName());
    	$attire->save();
    	return redirect('view-admin-all-attire');
    }
}
