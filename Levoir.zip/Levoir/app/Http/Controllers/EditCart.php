<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;
use App\Order;
use App\OrderDetail;
use Illuminate\Support\Facades\Auth;
class EditCart extends Controller
{
    function index($id){
		$order_detail = OrderDetail::where('id',$id)->first();
		$order = Order::where('id',$order_detail->order_id)->first();

    return view('my-layouts.edit-cart',compact('order_detail','order'));
	}


	function update(Request $request,$id){
	$attire = Attire::where('id',$id)->first();
	$new_order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();
	$order_detail = OrderDetail::where('attire_id',$attire->id)->where('order_id',$new_order -> id)->first();
		$order_detail->quantity =  $request->quantity;
        $order_detail->rent_time =  $request->rent_time;
		$new_price = $attire->price*$request->quantity;
		$order_detail->total_price = $new_price;
		$order_detail->update();

		$order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();
	$order->total_price= $attire->price*$request->quantity;
	$order->update();

		return redirect('view-cart');

	}

	function delete($id){
		$order_detail = OrderDetail::where('id',$id)->first();
		$order = Order::where('id',$order_detail->order_id)->first();
		$order->total_price = $order->total_price-$order_detail->total_price;
		$order->update();

		$order_detail->delete();

		return redirect('my-layouts.view-cart');
	}
}

