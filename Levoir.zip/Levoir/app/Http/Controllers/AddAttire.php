<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;
use App\User;
use Auth;

class AddAttire extends Controller
{
    function index(){
    	return view('my-layouts.add-attire');
    }

    function validator(Request $request){
		return $request->validate([
			'attire_name' => 'required',
			'attire_price' => 'required',
			'attire_description' => 'required',
            'attire_stock' => 'required'
		]);
	}
    function add(Request $request){
        $attire_image = $request->file('assets');
       $attire_image = $request->attire_image;
        // if($attire_image){
        //     $attire_image->move('assets', $attire_image->getClientOriginalName());
        // }
    	$this->validator($request);
    	$attire = new Attire();
    	$attire ->name = $request->attire_name;
    	$attire ->price = $request->attire_price;
    	$attire->description = $request->attire_description ;
    	$attire->image = $request->attire_image->getClientOriginalName();
       $attire_image->move('assets',$attire_image->getClientOriginalName());
       $attire->seller = Auth::user()->name;
	   $attire->seller_email = Auth::user()->email;
       $attire->stock = $request->attire_stock;
    	$attire->save();
    	return redirect('home-user');
    }
}
