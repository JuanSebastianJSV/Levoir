<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;

class AttireDetail extends Controller
{
	function index($id){
		$attire = Attire::where('id',$id)->first();
    return view('my-layouts.attire-detail',compact('attire'));
	}
}