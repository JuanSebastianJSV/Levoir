<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;

class ViewAdminAllAttire extends Controller
{
    public function index()
    {
    	$attire = Attire::paginate(6);
    	return view('my-layouts.view-admin-all-attire',compact('attire'));
   }
}
