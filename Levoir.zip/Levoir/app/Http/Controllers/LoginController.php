<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
class LoginController extends Controller
{
    function showLoginForm(){
    	return view('my-layouts.login');
    }

    function validator(Request $request){
    	return $request->validate([
			'email' => 'required',
			'password' => 'required'
		]);
    }

  

    function login(Request $request){
    	$credentials = $request->only(['email','password']);
        $user = new User();
    	if(Auth::attempt($credentials,false)){
    		return redirect('home-user');
    	}
    	else{
    		return redirect()->back();
    	}
    }

    function logout(){
    	Auth::logout();
    	return redirect('home');
    }
}
