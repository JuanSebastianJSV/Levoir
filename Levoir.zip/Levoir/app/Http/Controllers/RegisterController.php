<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;

class RegisterController extends Controller
{	
	function showRegisterForm(){
		return view('my-layouts.register');
	}

	function validator(Request $request){
		return $request->validate([
			'name' => 'required',
			'email' => 'required|unique:users|email',
			'password' => 'required|min:3',
			'c_password'=>'required|min:3|same:password'
		]);
	}

    function register(Request $request){
    	$this->validator($request);

    	$user = new User();
    	$user['name'] = $request['name'];
    	$user['email'] = $request['email'];
    	$user['password'] = Hash::make($request['password']);
    	$user['role'] = 'Customer';
    	$user->save();
    	return redirect('login');
    }

}
