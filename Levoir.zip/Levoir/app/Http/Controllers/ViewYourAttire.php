<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;
use App\User;
use Illuminate\Support\Facades\Auth;

class ViewYourAttire extends Controller
{
    public function index(Request $request)
    {	
    	$search = $request -> get('search');
        $item = Attire::where('seller_email',Auth::user()->email)->get();
    	$src = Attire::where("name",'like','%'.$search.'%')->paginate(6);
        // dd($item);
    	return view('my-layouts.view-your-attire',compact('item','src'));
    }
}