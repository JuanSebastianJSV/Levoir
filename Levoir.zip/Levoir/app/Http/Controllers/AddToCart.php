<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attire;
use App\Order;
use App\OrderDetail;
use App\User;
use Illuminate\Support\Facades\Auth;
class AddToCart extends Controller
{
    function index($id){
		$attire = Attire::where('id',$id)->first();
    return view('my-layouts.add-to-cart',compact('attire'));
	}

	function order(Request $request,$id){
		$attire = Attire::where('id',$id)->first();
		$user = User::where('id',$id)->first();
		$date = date('Y-m-d H:i:s');

		if($request->quantity > $attire->stock)
    	{
    		return redirect('home-user');
    	}

		$check = Order::where('user_id',Auth::user()->id)->where('status',0)->first();

		if(empty($check)){
		$order = new Order();
		$order->user_id = Auth::user()->id;
		$order->date = $date;
		$order->attire_id = $attire->id;
		$order->status = 0;
		$order->total_price = 0;
		$order->seller_id = $user->id;
		$order->save();
	}


		$new_order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();

		$check_order_detail = OrderDetail::where('attire_id',$attire->id)->where('order_id',$new_order -> id)->first();

		if(empty($check_order_detail)){
		$order_detail = new OrderDetail();
		$order_detail->attire_id = $attire->id;
		$order_detail->order_id = $new_order->id;
		$order_detail->quantity = $request->quantity;
		$order_detail->rent_time = $request->rent_time;
		$order_detail->total_price = $attire->price*$request->quantity;
		$order_detail->save();
	}		
	else{
		$order_detail = OrderDetail::where('attire_id',$attire->id)->where('attire_id',$new_order -> id)->first();
		$order_detail->quantity =  $order_detail->quantity + $request->quantity;
		$order_detail->rent_time = $request->rent_time;
		$new_price = $attire->price*$request->quantity;
		$order_detail->total_price = $order_detail->total_price + $new_price;
		$order_detail->update();
	}

	$order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();
	$order->total_price = $order->total_price + $attire->price*$request->quantity;
	$order->update();

		return redirect('home-user');
	
	}

	function cart(){
		$order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();
		if(!empty($order)){
		$order_detail = OrderDetail::where('order_id',$order -> id)->get();
		return view('my-layouts.view-cart',compact('order','order_detail'));}
		else{
			$order = "Empty Cart";
			$order_detail = "Empty Cart";
		return view('my-layouts.view-cart',compact('order','order_detail'));
		}
	}

	function checkout(){
		$order = Order::where('user_id',Auth::user()->id)->where('status',0)->first();
		$order_id = $order->id;
        $order_detail = OrderDetail::where('order_id',$order_id)->get();
		$order->status = 1;
		$order->update();
		foreach($order_detail as $od){
			$attire = Attire::where('id',$od->attire_id)->first();
            $attire->stock = $attire->stock - $od->quantity; 
			$attire->update(); 
		}

		return redirect('view-transaction');
	}
}