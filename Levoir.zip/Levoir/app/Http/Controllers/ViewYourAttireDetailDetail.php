<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\OrderDetail;
use App\User;
use App\Attire;
use Illuminate\Support\Facades\Auth;
class ViewYourAttireDetailDetail extends Controller
{
  public function index($id){
  	$order = Order::where('id',$id)->first();
  	$order_detail = OrderDetail::where('order_id',$order->id)->get();
	// dd($order_detail);
  	$user = User::get();

  	return view('my-layouts.view-your-attire-detail-detail',compact('order','order_detail','user'));
  }
}
